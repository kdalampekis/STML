"""Download ARCTraj from Hugging Face into data/raw/arctraj/.

Run this in your Mac's own Terminal (not inside Claude's Linux environment, which
cannot reach Hugging Face):

    cd ~/Research_Projects/STML
    python3 -m pip install --user datasets
    python3 scripts/download_arctraj.py

If Hugging Face says the dataset needs a login, run `huggingface-cli login` first.
It saves every split as JSON Lines plus a short description of the fields, which
is what the converter reads. Nothing else is changed.
"""

import json
from pathlib import Path

from datasets import load_dataset

OUT = Path(__file__).resolve().parents[1] / "data" / "raw" / "arctraj"
OUT.mkdir(parents=True, exist_ok=True)

ds = load_dataset("SejinKimm/ARCTraj")
info = {}
for split, d in ds.items():
    path = OUT / f"{split}.jsonl"
    d.to_json(str(path), lines=True, force_ascii=False)
    info[split] = {"rows": len(d), "features": {k: str(v) for k, v in d.features.items()}}
    print(f"{split}: {len(d)} rows -> {path}")
(OUT / "fields.json").write_text(json.dumps(info, indent=1))
sample = ds[list(ds.keys())[0]][0]
print("fields:", list(sample.keys()))
print("done. Tell Claude the download finished.")
