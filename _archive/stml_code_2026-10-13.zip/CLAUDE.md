# STML: Socratic Topological Meta-Learning

This file is the project brief for Claude Code. Read it fully before doing anything in this
folder. It explains the idea, the hypotheses, the architecture and its math, the code, the
game, the datasets, the results so far (including what went wrong), the current goal, and
the rules for working here.

Owner: Kostas Bekis. Folder: `~/Research_Projects/STML` on a MacBook (Apple M5, macOS).
Everything runs **on this Mac**, using the Apple GPU through PyTorch's Metal backend (`mps`).
Logs, datasets and results stay in this folder. No git for now.

---

## 1. The idea in one paragraph

Standard imitation learning copies **what** people answer. STML copies **how** people learn:
the wrong guesses, the moment a contradiction is noticed, and the revision that follows. The
learner reasons in an explicit graph, not in text. A Socratic critic tells it *why* something
failed, not just *that* it failed. A SAT solver acts as an independent referee that certifies
every verdict and is never visible to the learner. The learner is first trained to imitate
human learning trajectories (Stage A), then pushed past human efficiency with reinforcement
learning (Stage B).

The original chain of reasoning (the owner's): understand how people learn → translate that
process into something a machine can learn (imitation + RL) → a machine that learns like
people can understand context (transfer) → if it understands, it can produce new knowledge →
if it produces knowledge, it can form its own concepts and, eventually, its own language. A
fourth idea: a learner that **knows what it does not know**, saying "I don't know yet"
instead of inventing an answer, while still trying to build the missing knowledge.

## 2. Hypotheses

- **H1, process imitation.** A learner trained on human learning trajectories (mistakes and
  corrections included) learns new domains faster and transfers better than the same learner
  trained on RL-agent learning histories (Algorithm Distillation) or on scalar reward.
- **H2, diagnostic feedback.** Structured critiques (which rule failed, which premises are
  responsible, a countermodel) teach faster than a right/wrong signal, for the same learner.
- **H3, knowing what it does not know.** With knowledge stored as an explicit verified graph
  and a reward that makes honesty pay, the learner says "I don't know yet" when it has neither
  a proof nor a counterexample, and stays calibrated on problems harder than its training.

Kill criteria: if human trajectories give no advantage over RL histories, report it and keep
H2/H3; if critiques never beat scalar reward; if abstention does not track real difficulty.

## 3. Related work (closest)

- Algorithm Distillation (Laskin et al., ICLR 2023): imitate RL agents' learning histories →
  in-context RL. STML imitates **human** histories instead.
- MLC (Lake & Baroni, Nature 2023): human-like generalization by meta-learning, without
  imitating human behavioural data.
- Critique-GRPO, Text2Grad (2025): RL from text critiques for LLMs. STML: structured critiques,
  non-linguistic graph learner.
- Abductive Learning (Dai et al., NeurIPS 2019); AlphaGeometry (Nature 2024): neural proposer +
  symbolic checker.
- Kadavath et al. 2022 and R-Tuning (NAACL 2024): LLMs saying "I don't know". STML defines
  "don't know" as the absence of a certificate.
- Name clash to avoid: "RLEF" is Meta's RL from Execution Feedback (ICML 2025).

Full proposal (living document): https://claude.ai/code/artifact/c35b18e7-137c-4dfd-87a6-014cc1326c5d

## 4. Architecture and math

### 4.1 The logic domain (the main sandbox)

Categorical logic (syllogisms) over invented kinds ("wugs", "daxes"), i.e. basic set theory:

| Statement | Set reading |
| --- | --- |
| All A are B | A ⊆ B |
| No A are B | A ∩ B = ∅ |
| Some A are B | A ∩ B ≠ ∅ |
| Some A are not B | A \ B ≠ ∅ |

Every kind is non-empty. A world is a set of inhabited "regions" (exact subsets of kinds).
Universal statements force regions empty; existential ones need an inhabited region. So
satisfiability is exact, entailment is `premises ∧ ¬claim` unsatisfiable, and every claim is
**follows / contradicted / open**. Small-model property: a countermodel needs at most one
individual per existential statement.

Proof rules (Barbara, Celarent, Darii, Ferio, Baroco, Bocardo, plus conversion, identity,
existence) are **tested sound and complete** against the semantics, so every true claim has
a named proof and every open claim has a concrete countermodel.

### 4.2 The SAT referee

Variables x[j][i] = "individual j is a K_i"; one witness individual per existential statement;
All/No become clauses over all individuals; Some/Some-not fix the witness. Polynomial size;
PySAT + CaDiCaL. UNSAT → unsat core (which premises a verdict needs); SAT → countermodel.
Agreed with the semantics on 13,252 of 13,252 checks; solves 40-kind worlds in milliseconds.
**The learner never calls the referee** (otherwise "I know" is trivial and H3 is void).

### 4.3 The STML learner (`stml/model/`)

```
state graph(s) ──► relational GNN ──► graph embeddings
                                         │
task token (ARC: mean over example pairs [in, out, out−in]; + test input)
candidate tokens (each possible answer, read against task and test input)
                                         │
history transformer (causal): [task, attempt 1 + feedback, attempt 2 + feedback, …]
                                         │
     choice head: score per candidate (what to try next)
     confidence head: P(this answer is right) (what it knows, for H3)
```

- **Graphs** (`graphs.py`). ARC grid → object graph: nodes = 4-connected one-colour objects
  (colour, size, bounding box, centroid, background flag); edge types touch, same_color,
  same_shape, aligned_row, aligned_col. Logic world → concept graph: nodes = kinds (no names,
  so renaming changes nothing); 16 edge types = {All, No, Some, Some-not} × {given, proven,
  refuted, open}.
- **Relational GNN** (`network.py`): h_v ← h_v + ReLU(LN(W₀h_v + Σ_r mean_{u∈N_r(v)} W_r h_u)),
  3 layers, mean+max pooling. Pure PyTorch (no graph library) so it runs on Metal.
- **History transformer**: 2 layers, 4 heads, causal mask; tokens = candidate embedding +
  feedback embedding + attempt position. This is where learning from one's own mistakes
  happens in context.
- **Stage A** (`train.py: fit_imitation`): cross-entropy on the next choice in a learning
  history + BCE for the confidence head on whether that choice was right.
- **Stage B** (`train.py: train_rl`): REINFORCE, reward 1 − 0.25·(attempt−1) if solved, moving
  baseline, entropy bonus; confidence head trained on its own outcomes. Every choice is
  recorded so its learning history can be imitated (the Algorithm Distillation control).
- **Device**: `pick_device()` → `mps` (Apple Metal) if available, else `cuda`, else `cpu`.

### 4.4 Human learning model (Pillar 1, for the cognitive learner, not built yet)

Surprise δ_t = o_t − ô_t(G_t); accumulated S_t. Small surprise → assimilation (adjust beliefs);
S_t > τ → accommodation: G_{t+1} = argmin edit(G_t, G') + λ·violations + μ·MDL(G'). Socratic
question q* = argmax information gain about which assumption is wrong. Reported confidence
κ ∈ {1..5} is a noisy readout of belief.

### 4.5 H3 answer rule

Four answers: follows / contradicted / open / "I don't know yet". Reward +1 correct, −λ wrong,
−k for "don't know" (0 < k < λ). Commit only if p > (λ − k)/(1 + λ); e.g. k = 0.2: λ = 1 → 0.40,
λ = 4 → 0.76. Train at several λ and report the risk–coverage curve. A correct answer without a
certificate counts as a lucky guess, not knowledge.

## 5. The game: Wugs and Daxes (human data)

`game/template.html`, built by `scripts/build_game.py` into `game/index.html`. 5 levels × 3
worlds (Chains, Exclusion, Some, Exceptions, Transfer). Players propose statements that must
follow, rate confidence 1–5 before each answer, can mark the premises they used and say why.
The critic answers with a status, a Socratic question, and on request a proof (named rules) or
a countermodel world with the individual that breaks the claim. After each world: a test round
of 4 statements answered with **must be true / must be false / can't tell / I don't know yet**
(H3 data), then a one-sentence reflection.

- Published version (the owner is playing it now): https://claude.ai/artifact/74tWZmQeXUT5P43UYdjt7h
  Logs from that page go to the page's private research store (only the owner can read all of
  them). Claude on claude.ai can export them; Claude Code cannot reach that store. The page's
  **Download log** button gives the same log as a file: put it in `logs/<participant>/`.
- Local version: `python scripts/play_local.py` → http://127.0.0.1:8000; every move is saved
  automatically to `logs/<participant code>/<session>_<world>.json`.
- Log schema `stml-log/1` (see `stml/trajectories.py`). Analyse with
  `python scripts/analyze_log.py logs/<participant>`.
- The owner's own run is a usability pilot, **not data** (he knows the rules and hypotheses).

## 6. Datasets

All sources are converted to one format, **`stml-traj/1`** (`stml/datasets/common.py`): one
record per learner × task, with attempts (actions, commit, feedback, explanation, analysis),
timed explanations, epistemic judgments and outcome. The premise (itself testable): the human
learning loop (hypothesis → act → commit → feedback → revise → explain) has the same shape in
every domain.

### H-ARC (in `data/raw/harc/`, converted by `stml/datasets/harc.py`)

LeGris, Vong, Lake & Gureckis, *Scientific Data* 2025. Data from OSF (https://osf.io/bh8yq);
task files from https://github.com/Le-Gris/h-arc (`arc_data/`). Facts checked on the real data:

- 586,266 actions, 1,729 participants (1,393 finished), 800 tasks; up to 3 attempts with
  right/wrong feedback; an explicit `submit` action ends each attempt.
- **Every action row carries the full output grid**, so distance to the answer is known at
  every step (`d` on each action in our format).
- The **first rule description is written during attempt 1, before any feedback**; after the
  final submit people either write a revised description (2,771) or keep the first (6,061).
  Stored as timed `explanations` (initial / revised), with a quality flag.
- Validation: per-task solve rate 76.2% on training tasks, exactly the published figure
  (evaluation tasks 65.3% vs 64.2% published; we keep only finishers).
- Findings: first-attempt accuracy rises 50% → 58% from a person's 1st to 5th puzzle (random
  task order: **learning to learn**); after a wrong answer 52% of revisions get closer and 30%
  further; 48% of wrong submissions came after the person had been closer earlier in the same
  attempt (hypothesis switching, not hill-climbing); after a mistake people keep the grid size
  86% of the time and keep a median 93% of cells (local repair).

Convert: `python scripts/convert_datasets.py harc --data data/raw/harc/data --arc data/raw/harc/arc_data`
→ `data/processed/harc.jsonl` (≈48 MB, 7,871 records).

### ARCTraj (to download on the Mac)

~10,000 human trajectories on 400 ARC tasks with every action, including undo/redo
(arXiv 2511.11079; Hugging Face `SejinKimm/ARCTraj`). Download with
`python scripts/download_arctraj.py` (needs `pip install datasets`; may need
`huggingface-cli login`). It writes `data/raw/arctraj/*.jsonl` and `fields.json`.
**Next task: inspect the real fields, then write `stml/datasets/arctraj.py`** to convert to
`stml-traj/1` (same as H-ARC: read the data first, never guess the layout).

### Planned

Sudoku-Bench CTC (2,565 expert solves with spoken reasoning + moves); CMU DataShop tutor logs
(step-level, with errors and hints, including logic tutors).

## 7. Experiments so far

### 7.1 First experiment: `experiments/baseline_v1/` (linear choice model, hand features)

Protocol (kept for all H-ARC experiments): unseen puzzles, 50/50 puzzle split per seed, 5
splits; for each puzzle the learner chooses among the answers people actually gave (median 8;
the correct one is present in 787/800 puzzles); 3 attempts with right/wrong feedback. Same model
and same number of training steps in every condition; only the data source differs.

Results (from a run in Claude's cloud workspace, after the bug fix below; **re-run locally to
get logs**):

| Condition | Solved in 3 | Right first | Human-likeness | (revisions) |
| --- | ---: | ---: | ---: | ---: |
| Imitate human learning | 65.8% | 34.0% | **−2.00** | **−1.90** |
| Imitate answers | 66.5% | 34.2% | −2.77 | −3.16 |
| Imitate RL learning history | 66.8% | 34.4% | −2.79 | −3.12 |
| RL agent itself (best of 5 restarts) | 66.6% | 34.1% | −3.96 | −4.58 |
| Random choice | 45.8% | 18.9% | −2.23 | −2.36 |
| People | 71.4% | 54.9% | – | – |

Human-likeness = mean log-likelihood of people's actual next choices on unseen puzzles
(higher = more human-like). Differences in solving are all within ±1.2 points; every 95% CI
includes 0. **H1 is not supported in this setup.**

What we learned:
- The human-trained model is the **only** one that predicts how people revise better than
  chance. Human revision behaviour is systematic and learnable (it prefers answers similar to
  the one that just failed: local repair).
- The bottleneck is representation: every model gets ~34% right first time vs 55% for people,
  because it sees puzzles only through 12 hand-made features. A learner that cannot perceive
  the rule cannot benefit from a better learning strategy, whoever it imitates.
- Performance collapses on puzzles with many candidate answers (16+ answers: 34% solved), which
  is exactly where perception matters.

What went wrong (keep these in mind; each was caught and fixed):
1. **Unfair baseline.** The first run showed human histories +4.3 points over RL histories with
   a CI excluding 0. It came entirely from 2 of 5 splits where REINFORCE got stuck (~50%).
   Fix: RL restarts, best chosen on training puzzles only. Then the gap vanished.
2. **Wrong metric.** "Mean probability of the human choice" rewarded an overconfident model.
   Fix: log-likelihood (a proper score).
3. **Scaling bug.** The RL agent standardized features using fresh-start states only, where the
   history features are always 0 → divided by ~0 → its weight on "similarity to the failed
   answer" was 8,425. Fix: features with no spread keep unit scale (`_scale`).
4. **Design limits that remain:** the candidate pool comes from people (it leaks human
   knowledge into every condition and makes recovery easy as the pool shrinks); the model was
   memoryless across tasks, so the learning-to-learn effect (50% → 58%) could not be used.

### 7.2 Current experiment: `experiments/harc_h1_stml.py` (our architecture)

Same protocol, but the learner is the STML learner: it reads the real grids through the
object-graph GNN and conditions on its attempt history with the transformer. Conditions:
imitate human learning; imitate answers; RL from scratch (best of restarts, chosen on training
puzzles); imitate the RL agent's learning history (same step budget); **STML pipeline: imitate
humans, then RL**. Reports solve rate, first-try, recovery, human-likeness, and confidence
calibration (Brier, ECE).

**Status: written, not yet run.** First steps on the Mac: run the tests, then
`--quick`, then the full run.

## 8. Goals, in order

1. Get the environment working on the Mac with Metal; all tests pass.
2. Convert H-ARC; run `baseline_v1` locally to reproduce section 7.1 with local logs.
3. Run `harc_h1_stml.py --quick`, then the full run. Compare with baseline_v1. The question:
   does a learner that can actually perceive the puzzles benefit from human learning histories?
4. Download and convert ARCTraj; add it to Stage A pretraining (cross-dataset).
5. Add cross-task context (the transformer sees earlier puzzles of the same person) to test
   learning to learn.
6. Move the main H1/H2/H3 tests to the logic domain (`stml/env.py`), where hypotheses are
   represented exactly (concept graphs) and the human data comes from Wugs and Daxes.
7. Build the cognitive learner (Pillar 1) for synthetic human-like trajectories.
8. Human study: IRB at UCLA, consent screen in the game, 30–50 then 200–300 participants.

## 9. Code map

```
stml/logic.py, proof.py      exact semantics; named-rule proofs (sound + complete)
stml/world.py                hidden worlds and the 5-level curriculum
stml/critic.py               Socratic critic
stml/referee.py              SAT referee (never used by the learner)
stml/metacog.py              four epistemic answers, honesty reward, calibration metrics, probes
stml/env.py                  agent environment (propose claims; judge with four answers)
stml/analysis.py             classify human reasoning errors
stml/episodes.py             the 15 game worlds; trajectories.py: game logs → trajectories
stml/datasets/               stml-traj/1 format; H-ARC and game converters
stml/model/                  THE STML LEARNER: graphs, network, H-ARC data, training
stml/runlog.py               run folders: config, environment, log, metrics, results, report
experiments/harc_h1_stml.py  current experiment (our architecture)
experiments/baseline_v1/     first experiment (linear choice model), kept as reference
game/                        Wugs and Daxes
scripts/                     setup_mac.sh, build_game, play_local, analyze_log,
                             convert_datasets, download_arctraj
tests/                       core logic, datasets, model
data/raw, data/processed     datasets (not code); logs/ game logs; runs/ experiment runs
```

## 10. How to run (macOS, Apple Silicon, Metal)

```bash
cd ~/Research_Projects/STML
bash scripts/setup_mac.sh                 # creates .venv, installs requirements, checks Metal
source .venv/bin/activate
python -m pytest -q                       # all tests must pass
python scripts/convert_datasets.py harc --data data/raw/harc/data --arc data/raw/harc/arc_data
python experiments/baseline_v1/run.py --seeds 5          # ≈8 min, reproduces 7.1
python experiments/harc_h1_stml.py --quick               # smoke test
python experiments/harc_h1_stml.py --seeds 5             # the real run
python scripts/download_arctraj.py                       # ARCTraj from Hugging Face
python scripts/play_local.py                             # play the game locally, logs to logs/
```

If an operation is not implemented on Metal, run with `PYTORCH_ENABLE_MPS_FALLBACK=1`, or pass
`--device cpu` to compare.

## 11. Rules for Claude Code in this folder

- Run everything here, on this Mac. Use Metal (`mps`) for training.
- Every experiment goes through `stml.runlog.Run`: a new folder in `runs/`, never overwrite.
  Write a short `report.md` for every run that matters.
- Never delete or modify anything in `data/raw/` or `logs/`; they are original data.
- Inspect a dataset's real fields before writing a converter. Validate converted data against
  the paper's published numbers when possible.
- Be honest about results: same model and data budget across conditions; fair baselines (RL
  restarts chosen on training data only); proper scores (log-likelihood, Brier); report CIs and
  per-split numbers; a null result is a result. Check suspicious numbers before believing them.
- Keep the referee away from the learner.
- No git for now.
