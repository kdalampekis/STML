"""The STML learner on tiny synthetic puzzles: graphs, a forward pass, learning, play."""

import pytest

torch = pytest.importorskip("torch")

from stml.model.graphs import ARC_EDGE_TYPES, ARC_NODE_DIM, concept_graph, grid_graph  # noqa: E402
from stml.model.harc_data import Puzzle, Step  # noqa: E402
from stml.model.network import STMLLearner, pick_device  # noqa: E402
from stml.model.train import evaluate, fit_imitation, play, train_rl  # noqa: E402


def _puzzle(name: str, flip: bool) -> Puzzle:
    """Rule: mirror the grid left-right. Candidates: the input, the mirror, a blank grid."""
    a, b = "|120|300|", "|021|003|"
    cands = sorted([a, b, "|000|000|"])
    p = Puzzle(name, [(a, b), ("|450|006|", "|054|600|")], a, b, cands)
    p.graph_train = [(grid_graph(x), grid_graph(y)) for x, y in p.train]
    p.graph_test_in = grid_graph(p.test_input)
    p.graph_cands = [grid_graph(c) for c in p.candidates]
    return p


def test_grid_graph_objects_and_edges():
    g = grid_graph("|110|100|002|")
    assert g.x.shape[1] == ARC_NODE_DIM
    assert g.n == 3                                     # the 1-blob, the 0-region, the single 2
    assert set(g.edges[:, 2]) <= set(range(len(ARC_EDGE_TYPES)))
    assert (g.edges[:, 2] == 0).any()                   # some objects touch


def test_concept_graph():
    g = concept_graph(3, [("all", 0, 1, "given"), ("no", 1, 2, "proven")])
    assert g.n == 3 and len(g.edges) == 2


def test_learner_learns_and_plays():
    device = torch.device("cpu")
    puzzles = {f"p{i}": _puzzle(f"p{i}", i % 2 == 0) for i in range(4)}
    model = STMLLearner(ARC_NODE_DIM, len(ARC_EDGE_TYPES), d=32).to(device)
    steps = [Step(n, [], p.target_index, True) for n, p in puzzles.items()] * 4
    before = evaluate(model, puzzles, sorted(puzzles), device, human=steps)["human_loglik"]
    fit_imitation(model, puzzles, steps, device, epochs=30, lr=3e-3, batch=4, log=lambda m: None)
    after = evaluate(model, puzzles, sorted(puzzles), device, human=steps)
    assert after["human_loglik"] > before                # it learned the choices it imitated
    assert after["solved"] == 1.0
    enc = model.encode_puzzles([puzzles["p0"]], device)[0]
    solved, k, confs = play(model, enc, puzzles["p0"])
    assert solved and k == 1 and 0.0 <= confs[0][0] <= 1.0


def test_rl_records_its_history():
    device = torch.device("cpu")
    puzzles = {"p0": _puzzle("p0", True)}
    model = STMLLearner(ARC_NODE_DIM, len(ARC_EDGE_TYPES), d=16).to(device)
    hist = train_rl(model, puzzles, ["p0"], device, episodes=8, batch=4, log=lambda m: None)
    assert hist and all(isinstance(s, Step) for s in hist)


def test_pick_device_returns_a_device():
    assert pick_device().type in ("mps", "cuda", "cpu")
